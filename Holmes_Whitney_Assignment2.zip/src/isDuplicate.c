#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

/**
 * Compares an array of strings to itself to check for duplicates.
 * @author Whitney Holmes 3502092
 * @returns 0 if duplicate
 * @returns 1 if not duplicate
 */
int isDuplicate(char * tagArray, int arrayLength) {
    char * nextTag = tagArray + 1;
    int i;
    int j;
    char *eol = "\0";

    for(i = 0; i < arrayLength; i++) {
        printf("tagArray = %d\n", (int)*tagArray);
        printf("nextTag = %d\n", (int)*nextTag);
        for(j = i + 1; j < arrayLength; j++) {
            if(strcmp(tagArray, nextTag) == 0) {
                return 0; //If duplicate, return true
            }
            nextTag++; 
        } 
        if(strcmp(tagArray, eol) == 0) {
            return 0;
        }
        tagArray++;
    }
    return 1; //Return false if distinct
}