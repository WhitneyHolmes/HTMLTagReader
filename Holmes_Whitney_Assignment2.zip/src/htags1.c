#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"

#define ROWS 100
#define COLS 10
/**
 * Scans from a pointer of an HTML file (from stdin)
 * until EOF. 
 * Adds tags to an array passed in.
 * Checks for an "<", and terminates the 
 * tag when a " ", "/", or ">" is encountered.
 * @author Whitney Holmes - 3502092
 */
int main()
{
    char tagArray[ROWS][COLS];
    char character = getchar();
    int tagIndex = 0;
    int charIndex = 0;
    char eol = '\0';


    while(character != EOF && tagIndex < ROWS) {
        if(character == '<') {
            character = getchar();
            while(character != '/' || charIndex < COLS -1) {
                if(isIllegalCharacter(character) == 1) {
                    printf("dec: %d\n", (int)character);
                    tagArray[tagIndex][charIndex] = character;
                    charIndex++;
                }
                else {
                    tagArray[tagIndex][charIndex] = eol;
                    if(isDuplicate(&tagArray[0][0], tagIndex) == 1) { //not duplicate
                        tagIndex++;
                        printf("Tag index incremented\n"); 
                    }
                    charIndex = 0;
                    break;
                }
                character = getchar(); 
            }
            printf("Tag index = %d\n", tagIndex);
        }
        character = getchar();
    }
    printf("The tags used are:\n");
    int i;
    for(i = 0; i < tagIndex; i++) {
        printf("%s\n", tagArray[i]);
    }
}
    